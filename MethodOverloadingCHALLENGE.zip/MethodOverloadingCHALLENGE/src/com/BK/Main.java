package com.BK;

public class Main {

    public static void main(String[] args) {
        double centimeters =calcFeetAndInchesToCentimeters(6,0);
        if(centimeters< 0.0) {
            System.out.println("Invalid Parameters");
        }
        calcFeetAndInchesToCentimeters(100);
    }

    public static double calcFeetAndInchesToCentimeters(double feet, double inches) {
        if(feet < 0 || (inches < 0) || (inches > 12)) {
            System.out.println("ERROR! Invalid feet or inches parameters");
            return -1;
        }
        double centi = (feet*12)*(2.54);
        centi += inches*2.54;
        System.out.println("Feet: " + feet + "ft \nInches: " + inches + "in \n" +
                "Total Centimeters: " + centi + "cm");
        return centi;

    }

    public static double calcFeetAndInchesToCentimeters(double inches) {
        if(inches < 0) {
            return -1;
        }
        double feet = (int)inches/12;
        double remInches = (int)inches%12;
        System.out.println(inches + "in is equal to " + feet + "ft and " + +remInches + "in");
        return calcFeetAndInchesToCentimeters(feet, remInches);

    }

}
