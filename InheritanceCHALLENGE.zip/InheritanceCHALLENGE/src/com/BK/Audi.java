package com.BK;

/**
 * Created by bk on 8/12/16.
 */
public class Audi extends Car {

    private String audiName;
    private int leather;
    private int bose;

    public Audi(int body, int engine, int headlights, int brakelights, String carType, int wheels, int windows, String audiName, int leather, int bose) {
        super(1, engine, 2, 2, "Audi", 4, 6);
        this.audiName = audiName;
        this.leather = leather;
        this.bose = bose;
    }

    public void acceleration(double zeroTOsixty) {
        System.out.println("Audi.acceleration called");
        System.out.println("Car can reach 60 seconds in " + zeroTOsixty +" seconds");
    }
}
