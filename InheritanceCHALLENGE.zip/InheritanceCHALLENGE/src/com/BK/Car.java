package com.BK;

/**
 * Created by bk on 8/12/16.
 */
public class Car extends Vehicle {

    private int wheels;
    private int doors;
    private int gears;

}
