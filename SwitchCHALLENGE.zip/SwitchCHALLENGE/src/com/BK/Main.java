package com.BK;

public class Main {

    public static void main(String[] args) {
        //create a new switch statement using char instead of int
        //create a new char variable
        //create a switch statement testing for ...
        //A, B, C, D, E
        //display a message if any of these are found and then break

        char switchVal = 'F';
        switch (switchVal) {
            case 'A':
                System.out.println("Character A");
                break;
            case 'B':
                System.out.println("Character B");
                break;
            case 'C':
                System.out.println("Character C");
                break;
            case 'D':
                System.out.println("Character D");
                break;
            case 'E':
                System.out.println("Character E");
                break;
            default:
                System.out.println("A, B, C, D, nor E were the values");
                break;
        }

        String month = "JANUARY";
        month = month.toLowerCase();
        switch (month){
            case "january":
                System.out.println("Jan");
                break;
            case "october":
                System.out.println("Oct");
                break;
            default:
                System.out.println("Not Sure");

        }


    }

}