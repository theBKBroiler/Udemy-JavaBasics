package com.BK;

public class Main {

    public static void main(String[] args) {

        Bank bankInfo = new Bank();
        System.out.println(bankInfo.getAccNum());
        System.out.println(bankInfo.getBalance());


        bankInfo.withdraw(100.0);

        bankInfo.deposit(50.0);
        bankInfo.withdraw(100.0);

        bankInfo.deposit(51.0);
        bankInfo.withdraw(100.0);

        Bank newBankInfo = new Bank("Ken","ken@email.com",12345);
        System.out.println(newBankInfo.getAccNum() + " name " + newBankInfo.getCustName());

    }


}
