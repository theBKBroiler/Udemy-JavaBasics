package com.BK;


/**
 * Created by bk on 8/7/16.
 */

public class Bank {

    private int accNum;
    private double balance;
    private String custName;
    private String email;
    private long phoneNum;
    private double withAmt;
    private double depAmt;


    public Bank() {
        this(1234, 2.50,"NAME","EMAIL",708846111);
        System.out.println("EMPTY CONSTRUCTOR");
    }

    public Bank(int accNum, double balance, String custName, String email, long phoneNum) {
        System.out.println("Account constructor with parameters called");
        this.accNum = accNum;
        this.balance = balance;
        this.custName = custName;
        this.email = email;
        this.phoneNum = phoneNum;
    }

    public Bank(String custName, String email, long phoneNum) {
        this(99999,100.55,custName,email,phoneNum);
        this.custName = custName;
        this.email = email;
        this.phoneNum = phoneNum;
    }

    public void deposit(double depAmt) {
        this.balance += depAmt;
        System.out.println("Deposit of $" + depAmt + " made. New balance: $" + this.balance);
    }

    public void withdraw(double withAmt) {
        if(balance - withAmt <= 0) {
            System.out.println("Only $" + balance + " available. Withdrawal not processed");
        } else {
            this.balance -= withAmt;
            System.out.println("Withdrawal of " + withAmt + " processed. Remaining balance: $" + this.balance);
        }
    }

    //commence setters

    public void setAccNum(int accNum) {
        this.accNum = accNum;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhoneNum(long phoneNum) {
        this.phoneNum = phoneNum;
    }

    public void setDepAmt(double depAmt) {
        this.depAmt = depAmt;
    }

    public void setWithAmt(double withAmt) {
        this.withAmt = withAmt;
    }

    //commence getters

    public int getAccNum() {
        return this.accNum;
    }

    public double getBalance() {
        return this.balance;
    }

    public String getCustName() {
        return this.custName;
    }

    public String getEmail() {
        return this.email;
    }

    public double getPhoneNum() {
        return this.phoneNum;
    }

    public double getDepAmt() {
        return this.depAmt;
    }

    public double getWithAmt() {
        return this.withAmt;
    }


}
