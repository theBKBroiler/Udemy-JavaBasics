package com.BK;

public class Main {

    public static void main(String[] args) {

        System.out.println("THIS IS THE DEFAULT");
        VipCustomer customer1 = new VipCustomer();
        System.out.println("NAME: " + customer1.getName());

        System.out.println("-------------------------------------------------");

        System.out.println("THIS IS CONSTRUCTOR #2");
        VipCustomer customer2 = new VipCustomer("NIGGERS",5000.0);
        System.out.println(customer2.getName() + " has a CREDIT LIMIT of: $" + customer2.getCreditLimit());

        System.out.println("-------------------------------------------------");

        System.out.println("THIS IS CONSTRUCTOR #3");
        VipCustomer customer3 = new VipCustomer("BILLYBOB",100.0,"nunyerbiz@nsa.gov");
        System.out.println("NAME: " + customer3.getName() + "\n" +
                "CREDIT LIMIT: $" + customer3.getCreditLimit() + "\n" +
                "EMAIL: "  + customer3.getEmail());

    }
}
