package com.BK;

/**
 * Created by bk on 8/9/16.
 */
public class VipCustomer {

    //CHALLENGE INSTRUCTIONS

    //create a new class VipCustomer
    //It should have 3 fields ... name, creditLimit, and emailAddress
    //create 3 constructors
    //1st constructor empty should call the constructor with 3 parameters w/ default values
    //2nd constructor should pass on the 2 values it receives and add a default value for the 3rd
    //3rd constructor should save all fields
    //create getters only for this using code generation of intelliJ as setters wont be needed
    //test and confirm it works

    private String name;
    private double creditLimit;
    private String email;

    public VipCustomer() {
        this("DEFAULT NAME", 0.00, "DEFAULTEMAIL@EMAIL.COM");
    }

    public VipCustomer(String name, double creditLimit) {
        this(name,creditLimit,"DEFAULTEMAIL@EMAIL.COM");
    }


    public VipCustomer(String name, double creditLimit, String email) {
        this.name = name;
        this.creditLimit = creditLimit;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public double getCreditLimit() {
        return creditLimit;
    }

    public String getEmail() {
        return email;
    }

}
